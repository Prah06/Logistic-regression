import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, recall_score, precision_score,accuracy_score,f1_score 
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import pickle
import logging


# Configure logger
## Your code here
logging.basicConfig(filename ="chd_log",format ='%(asctime)s %(message)s',filemode='w')
logger = logging.getLogger()
logger.setLevel(logging.INFO)
# Read in test data
## Your code here
df = pd.read_csv('test.csv')
X = df.iloc[:, :-1]
Y = df.iloc[:, -1]
# Read in model
## Your code here
file=open('classifier.pkl','rb')
load_model = pickle.load(file)
load_scalar = pickle.load(file)
file.close()
# Scale X
## Your code here
scaler = load_scalar
standard_df = scaler.fit_transform(X)
classifier = load_model
classifier.fit(X, Y)

# Check accuracy on test data
## Your code here
y_pred = classifier.predict(X)
test_accuracy = accuracy_score(Y, y_pred)
print(f"Test Accuracy = {test_accuracy}")

# Show confusion matrix
## Your code here
cm=confusion_matrix(Y,y_pred)
print(f"Confusion matrix = \n{cm}")
# Try a bunch of thresholds
threshold = 0.0
best_f1 = -1.0
thresholds = []
recall_scores = []
precision_scores = []
f1_scores = []
i=0
while threshold <= 1.0:
    thresholds.append(threshold)
    ## Your code here
    y_pred = (classifier.predict_proba(X)[:,1] >= threshold)
    accuracy=accuracy_score(Y, y_pred)
    recall=recall_score(Y, y_pred)
    precision=precision_score(Y, y_pred)
    f1= f1_score(Y, y_pred)
    recall_scores.append(recall)
    precision_scores.append(precision)
    f1_scores.append(f1)
    logger.info(
        f"Threshold={threshold:.3f} Accuracy={accuracy:.3f} Recall={recall:.2f} Precision={precision:.2f} F1 = {f1:.3f}"
    )
    threshold += 0.02
    i+=1
    if (i>=40):
       break

# Make a confusion matrix for the best threshold
## Your code here
best_threshold=np.where(f1_scores == np.max(f1_scores))[0][0]
y_pred = (classifier.predict_proba(X)[:,1] >= thresholds[best_threshold])
cm=confusion_matrix(Y,y_pred)
print(f"Confusion matrix = \n{cm}")
# Plot recall, precision, and F1 vs Threshold
fig, ax = plt.subplots()
ax.plot(thresholds, recall_scores, "b", label="Recall")
ax.plot(thresholds, precision_scores, "g", label="Precision", color="g")
ax.plot(thresholds, f1_scores, "r", label="F1", color="r")
ax.vlines(thresholds[best_threshold], 0, 1, "r", linewidth=0.5, linestyle="dashed")
ax.set_xlim(0, 1)
ax.set_xlabel("Threshold")
ax.legend()
fig.savefig("threshold.png")
