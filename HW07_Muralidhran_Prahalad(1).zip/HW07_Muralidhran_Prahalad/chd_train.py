from lib2to3.pgen2.pgen import DFAState
import pandas as pd
from sklearn.linear_model import LogisticRegression
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Read the training data
print("Reading input...")
## Your code here
df = pd.read_csv('train.csv')
X = df.iloc[:, :-1]
Y = df.iloc[:, -1]
print("Scaling...")
## Your code here
scaler = StandardScaler()
print("Fitting...")
## Your code herer
standard_df = scaler.fit_transform(X)
classifier = LogisticRegression()
classifier.fit(X, Y)
# Get the accuracy on the training data
## Your code here
y_pred = classifier.predict(X)
train_accuracy = accuracy_score(Y, y_pred)
print(f"Training accuracy = {train_accuracy}")

# Write out the scaler and logisticregression objects into a pickle file
pickle_path = "classifier.pkl"
print(f"Writing scaling and logistic regression model to {pickle_path}...")
## Your code here
file=open('classifier.pkl', 'wb')
pickle.dump(classifier, file)
pickle.dump(scaler, file)
file.close()


